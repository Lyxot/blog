#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 此脚本将在post-fs-data模式下执行

mount -t tmpfs -o mode=755 tmpfs /sys/fs/cgroup && mkdir -p /sys/fs/cgroup/devices && mount -t cgroup -o devices cgroup /sys/fs/cgroup/devices && mkdir -p /sys/fs/cgroup/systemd && mount -t cgroup cgroup -o none,name=systemd /sys/fs/cgroup/systemd

for i in $(ls /system/etc/vintf/compatibility_matrix.*)
    do
        if [ -n "$(grep '<key>CONFIG_FHANDLE</key>' $i)" ]
            then
                sed '/<key>CONFIG_FHANDLE<\/key>/{n;s/<value type="tristate">n<\/value>/<value type="tristate">y<\/value>/;}' $i > $MODDIR$i
            fi
    done
