#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 此脚本将在post-fs-data模式下执行

for i in $(ls /system/etc/vintf/compatibility_matrix.*)
    do
        if [ -n "$(grep '<key>CONFIG_FHANDLE</key>' $i)" ]
            then
                sed '/<key>CONFIG_FHANDLE<\/key>/{n;s/<value type="tristate">n<\/value>/<value type="tristate">y<\/value>/;}' $i | sed '/<key>CONFIG_SYSVIPC<\/key>/{n;s/<value type="tristate">n<\/value>/<value type="tristate">y<\/value>/;}' > $MODDIR$i
                
            fi
    done
